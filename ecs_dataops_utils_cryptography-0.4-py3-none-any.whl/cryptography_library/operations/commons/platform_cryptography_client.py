import json
import requests
import pandas as pd
from pyspark.sql.functions import pandas_udf


DECRYPT_URL = "https://k8s-api-platform-prd.ecsbr.net/platform/decryptor/batch"


class PlatformCryptographyClient:
    def __init__(self):
        pass

    def decrypt(self, data: list, product: str, table="", crypt_type=""):
        """
        Function that makes Platform encryption API request.

        :param data: List of strings containing the encrypted data.
        :type data: list

        :param product: Product name. May be one of, but not restricted to\
        ["af", "lno", "ecred", ...]
        :type product: str

        :param table: Database table name.
        :type table: str, optional

        :param crypt_type: Cryptography type.
        :type crypt_type: str, optional

        :return: List of strings containing the decrypted data.
        :rtype: list
        """

        formated_data = map(
            lambda x: {
                "id": str(x[0]),
                "value": x[1]
            },
            enumerate(data)
        )
        filtered_values = list(filter(lambda x: x["value"], formated_data))

        if not len(filtered_values):
            return data

        payload = {
            "product": product,
            "crypt_type": crypt_type,
            "table": table,
            "rows": filtered_values
        }

        headers = {
            'X-ECS-APPLICATION-ID': 'datalake-ecs-ia',
            'Content-Type': 'application/json'
        }

        json_payload = json.dumps(payload)
        response = requests.post(
            DECRYPT_URL,
            headers=headers,
            data=json_payload
        )

        try:
            assert response.status_code == 200
        except AssertionError:
            raise ValueError(
                "Invalid API response status code "
                f"{response.status_code}, response: {response.text}"
            )

        rows = json.loads(response.text)['rows']

        mapper = {
            r["id"]: r["value"]
            for r in rows
        }

        result = [
            mapper.get(str(i), None)
            for i in range(len(data))
        ]

        return result

    def encrypt():
        """
        Not Implemented

        :raises: NotImplementedError
        """
        raise NotImplementedError("Ainda não temos essa funcionalidade")

    def get_decrypt_udf(self, product: str, table="", crypt_type=""):
        """
        Get a spark paralelizable udf (pandas_udf) that makes batch calls.

        :param product: Product name. May be one of, but not restricted to\
        ["af", "lno", "ecred", ...]
        :type product: str

        :param table: Database table name.
        :type table: str, optional

        :param crypt_type: Cryptography type.
        :type crypt_type: str, optional

        :return: Decryption UDF.
        :rtype: pandas_udf

        Using with pyspark:

        >>> client = PlatformCryptographyClient()
        >>> lnoDecrypt = client.get_decrypt_udf("lno")
        >>>
        >>> df = (
        >>>     spark_df
        >>>     .select(
        >>>         lnoDecrypt("encrypted_data").alias("decrypted_data")
        >>>     )
        >>> )
        >>> df.show(truncate=False)

        Using with SQL:

        >>> client = PlatformCryptographyClient()
        >>> lnoDecrypt = client.get_decrypt_udf("lno")
        >>>
        >>> spark.udf.register("decryptCPF", decryptCPF);

        >>> %sql
        >>> SELECT
        >>>     cryptedUserEmail, cryptedUserDocument,
        >>>     decryptCPF(cryptedUserDocument) AS cpf_aberto,
        >>> FROM DATABASE_EXEMPLO
        """
        @pandas_udf("string")
        def _udf(data: pd.Series) -> pd.Series:
            import os
            os.system("echo '10.155.219.246 k8s-api-platform-prd.ecsbr.net' \
            | sudo tee -a /etc/hosts")

            response = self.decrypt(
                data.values.tolist(),
                product,
                table,
                crypt_type
            )

            return pd.Series(response)

        return _udf
