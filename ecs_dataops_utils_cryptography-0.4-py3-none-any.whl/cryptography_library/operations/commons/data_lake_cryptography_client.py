import boto3
import binascii
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

default_cmk = "alias/encryption-api-cmk"
default_secrets_cmk = "alias/encryption-api-secrets-key"


class DataLakeCryptographyClient:
    """
        Classe herdada dos processos criados pela Daten Works
        para criptografia.
    """
    def __init__(self, kms_cmk=default_cmk, secrets_cmk=default_secrets_cmk):

        self.nonce = bytes(12)  # XXX: DON'T DO IT IN PRODUCTION

        self.kms_cmk = kms_cmk
        self.secrets_cmk = secrets_cmk
        self.aes_gcm = {}

    def create_data_key(self, name, description) -> dict:
        import base64

        kms = (
            boto3
            .session
            .Session()
            .client(
                service_name="kms",
                region_name='us-east-1'
            )
        )

        data_key_plaintext = (
            kms
            .generate_data_key(KeyId=self.kms_cmk, KeySpec="AES_256")
            .get("Plaintext")
        )

        data_key_b64 = base64.b64encode(data_key_plaintext)

        secrets_manager = (
            boto3
            .session
            .Session()
            .client(
                service_name="secretsmanager",
                region_name='us-east-1'
            )
        )

        response = secrets_manager.create_secret(
            Name=name,
            Description=(description or ""),
            KmsKeyId=self.secrets_cmk,
            SecretBinary=data_key_b64
        )

        return {"secretARN": response.get("ARN")}

    def _get_data_key(self, name) -> str:
        import base64

        data_key = None

        secrets_manager = (
            boto3
            .session
            .Session()
            .client(
                service_name="secretsmanager",
                region_name='us-east-1'
            )
        )

        try:
            secret = (
                secrets_manager
                .get_secret_value(SecretId=name)
                .get("SecretBinary")
            )
            data_key = base64.b64decode(secret)

        except secrets_manager.exceptions.ResourceNotFoundException:
            pass  # The `data_key` value will continue to be None

        return data_key

    def data_key_exists(self, name) -> bool:
        found = False
        secrets_manager = (
            boto3
            .session
            .Session()
            .client(
                service_name="secretsmanager",
                region_name='us-east-1'
            )
        )

        try:
            arn = (
                secrets_manager
                .describe_secret(SecretId=name)
                .get("ARN")
            )

            found = len(arn) > 0
        except secrets_manager.exceptions.ResourceNotFoundException:
            pass  # The `found` value will continue to be False

        return found

    def _get_aes_gcm_with_aliases(self, aliases):

        aes_gcm = {
            alias: AESGCM(
                key=self._get_data_key(name=f"encryption-key-for-{alias}")
            )
            for alias in aliases
        }
        return aes_gcm

    def encrypt_data(self, payload):
        import base64

        aliases = payload["columns"]

        for alias in aliases.values():
            if alias not in self.aes_gcm:
                self.aes_gcm = self._get_aes_gcm_with_aliases(
                    aliases=[alias]
                )

        results = {key: [] for key in aliases.keys()}

        # Values are converted to string before encryption, and
        # then encoded into
        # unicode (byte array). Facilitating idempotency between
        # languages and implementations for this cryptography
        for obj in payload["values"]:
            for key, value in obj.items():

                name = aliases[key]
                cripto = self.aes_gcm[name]

                encripted = cripto.encrypt(
                    self.nonce,
                    str(value).encode(),
                    associated_data=None
                )

                results[key].append({
                    "source": value,
                    "cypher": base64.b64encode(encripted).decode()
                })

        return results

    def decrypt_data(self, payload):
        import base64

        aliases = payload["columns"]

        for alias in aliases.values():
            if alias not in self.aes_gcm:
                self.aes_gcm = self._get_aes_gcm_with_aliases(
                    aliases=[alias]
                )

        results = {key: [] for key in aliases.keys()}

        none_payload = {
            "cypher": None,
            "source": None
        }

        for obj in payload["values"]:
            for key, value in obj.items():

                if value is None:
                    results[key].append(none_payload)
                    continue

                name = aliases[key]
                cripto = self.aes_gcm[name]

                try:
                    decripted = cripto.decrypt(
                        self.nonce,
                        base64.b64decode(value),
                        associated_data=None
                    ).decode()
                except (binascii.Error, InvalidTag):
                    raise ValueError(
                        f"Was not possible to decrypt data using the "
                        "given key: \n\tdata: {value}\n\tkey: {key}"
                    )

                register = {
                    "cypher": value,
                    "source": decripted
                }

                results[key].append(register)

        return results
