import json
import requests

HEADERS = {'X-ECS-APPLICATION-ID': 'datalake-ecs-ia'}

# endpoints of APIs
# TODO: Colocar em configuration files
BASE_URL = "https://k8s-api-platform-prd.ecsbr.net/platform"

encrypt_url = f'{BASE_URL}/encryptor/batch'
decrypt_url = f'{BASE_URL}/decryptor/batchapi'


class DocumentCryptographyClient:

    def __init__(self):
        self.encrypt_endpoint = encrypt_url
        self.decrypt_endpoint = decrypt_url

    def decrypt_documents(self, documents: list) -> list:
        """
            Decrypt document data using the API.

            :param documents: List of strings, containing the documents to \
                decrypt.
            :type documents: list

            :return: List of strings containing de decrypted documents.
            :rtype: list
        """
        payload = {"documents": documents}

        r = requests.post(
            self.decrypt_endpoint,
            json=payload,
            headers=HEADERS,
            timeout=100,
            verify=True
        )

        if r.status_code == 200:
            json_result = json.loads(r.text)['documents']
            return list(map(lambda x: x["document"], json_result))
        else:
            raise ValueError(
                f"Failed to call decrypt API."
                f"Status code: {r.status_code} Message: {r.text}"
            )

    def encrypt_documents(self, documents: list) -> list:
        """
            Encrypt documents using the API.

            :param documents: List of strings, containing the documents to \
                encrypt.
            :return: List of strings containing de encrypted documents.
            :rtype: list
        """
        payload = {"documents": list(map(str, documents))}

        r = requests.post(
            self.encrypt_endpoint,
            json=payload,
            headers=HEADERS,
            timeout=100,
            verify=True
        )

        if r.status_code == 200:
            json_result = json.loads(r.text)['documents']
            return list(map(lambda x: x["id"], json_result))
        else:
            raise ValueError(
                f"Failed to call encrypt API."
                f"Status code: {r.status_code} Message: {r.text}"
            )
