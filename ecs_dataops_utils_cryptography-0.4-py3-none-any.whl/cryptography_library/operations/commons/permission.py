from pyspark.sql.session import SparkSession


def check_permission(spark: SparkSession) -> dict:
    result = spark.sql(
        """
        SELECT
            current_user() as user,
            (
                is_member("lake_cryptography")
                OR is_member("admins")
            ) AS has_access
        """
    ).collect()[0]

    if not result.has_access:
        raise PermissionError(
            f"User \"{result.user}\" doesn't have permission"
            " to use this function"
        )

    return dict(
        has_access=result.has_access,
        user=result.user
    )
