import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.session import SparkSession
from .criptography_client import CriptographyClient


class SparkCryptography:

    def __init__(self, spark: SparkSession):
        """
            Creates a cryptography SparkCryptography client.

            :arg spark: Spark session.
            :type spark: SparkSession

        """
        self.client = CriptographyClient(spark)

    def get_encryption_function(self, field_type: str):
        """
        Returns a spark function (pandas_udf) to encrypt DataFrame fields.

        :arg field_type: Type of key used. Must be one of the existing keys.\
            If not valid will throw a ValueError.
        :return: Function (pandas_udf) to encrypt columns.
        :rtype: function
        """

        @pandas_udf("string")
        def _udf(data: pd.Series) -> pd.Series:
            import os
            os.system("echo '10.155.219.246 k8s-api-platform-prd.ecsbr.net' \
            | sudo tee -a /etc/hosts")

            response = self.client.encrypt(data.values.tolist(), field_type)
            return pd.Series(response)

        return _udf

    def get_decryption_function(self, field_type):
        """
        Returns a spark function (pandas_udf) to decrypt DataFrame fields.

        :arg field_type: Type of key used. Must be one of the existing keys.\
            If not valid will throw a ValueError.
        :return: Function (pandas_udf) to decrypt columns.
        :rtype: function
        """

        @pandas_udf("string")
        def _udf(data: pd.Series) -> pd.Series:
            import os
            os.system("echo '10.155.219.246 k8s-api-platform-prd.ecsbr.net' \
            | sudo tee -a /etc/hosts")

            response = self.client.decrypt(data.values.tolist(), field_type)
            return pd.Series(response)

        return _udf
