from pyspark.sql.session import SparkSession
from .commons import DataLakeCryptographyClient
from .commons import DocumentCryptographyClient
from .commons import check_permission


# The field name is standardized to "f", to reduce the payload
FIELD_NAME = "f"
KEY_NAMES = [
    "email", "phone", "address", "name",
    "date", "person_number", "geocode", "ip",
    "cpf", "cnpj", "rg", "titulo_eleitor"
]
DOCUMENT_KEYS = ["cpf", "cnpj", "rg", "titulo_eleitor", "documento"]


class CriptographyClient:

    def __init__(self, spark: SparkSession):
        permision = check_permission(spark)

        assert permision["has_access"]
        self.user = permision["user"]

        self.data_lake_client = DataLakeCryptographyClient(
            # TODO: Colocar esse cmk em um vault
            secrets_cmk="4bda4944-3f7b-47b2-9bff-69c5753398d4"
        )
        self.document_cyptography_client = DocumentCryptographyClient()

    @staticmethod
    def _data_lake_payload(data, field_type):
        """
        Function that formats the data into the desired format.

        :param data: List with the values.
        :type data: list

        :return: Formated payload.
        :rtype: dict

        """
        payload = {
            "columns": {FIELD_NAME: field_type},
            "values": [
                {FIELD_NAME: doc}
                for doc in data
            ]
        }
        return payload

    def _data_lake_decrypt(self, data: list, field_type: str):

        payload = self._data_lake_payload(data, field_type)

        response = (
            self
            .data_lake_client
            .decrypt_data(payload=payload)
        )

        return list(map(lambda x: x["source"], response[FIELD_NAME]))

    def _data_lake_encrypt(self, data: list, field_type: str):

        payload = self._data_lake_payload(data, field_type)

        response = (
            self
            .data_lake_client
            .encrypt_data(payload=payload)
        )

        return list(map(lambda x: x["cypher"], response[FIELD_NAME]))

    def _platform_document_decrypt(self, documents: list):
        return (
            self
            .document_cyptography_client
            .decrypt_documents(documents)
        )

    def _platform_document_encrypt(self, documents: list):
        return (
            self
            .document_cyptography_client
            .encrypt_documents(documents)
        )

    @staticmethod
    def _validate_field_type(field_type):
        """
        Function that validates that the field type is valid.
        Raises ValueError if not.

        :arg field_type: Tipo do campo.
        :type field_type: str

        :return: None
        :rtype: NoneType
        """
        try:
            assert field_type in KEY_NAMES
        except AssertionError:
            raise ValueError(
                f"Key not found: {field_type}"
                f" Must be one of {KEY_NAMES}."
            )

    def decrypt(self, data: list, field_type: str):
        """
        Decrypts data using field type key.

        :param data: List of strings. Data to be decrypted.
        :type data: list

        :param field_type: String indicating the field type.\
        Must be one of [
            "email", "phone", "address", "name","date", "person_number",\
            "geocode", "ip","cpf", "cnpj", "rg", "titulo_eleitor"].\
        When the value is one of ["cpf", "cnpj", "rg", "titulo_eleitor"]\
            the platform API is used, so the process may be slower than\
            the other fields

        :type field_type: str

        :return: Decrypted values.
        :rtype: list
        """

        self._validate_field_type(field_type)

        if field_type in DOCUMENT_KEYS:
            # Documents
            return self._platform_document_decrypt(data)
        else:
            # Other fields
            return self._data_lake_decrypt(data, field_type)

    def encrypt(self, data: list, field_type: str):
        """
        Encrypts data using field type key.

        :param data: List of strings. Data to be encrypted.
        :type data: list

        :param field_type: String indicating the field type.\
        Must be one of [
            "email", "phone", "address", "name","date", "person_number",\
            "geocode", "ip","cpf", "cnpj", "rg", "titulo_eleitor"].\
        When the value is one of ["cpf", "cnpj", "rg", "titulo_eleitor"]\
            the platform API is used, so the process may be slower than\
            the other fields.
        :type field_type: str

        :returns: Encrypted values.
        :rtype: list

        """

        self._validate_field_type(field_type)

        if field_type in DOCUMENT_KEYS:
            # Documents
            return self._platform_document_encrypt(data)
        else:
            # Other fields
            return self._data_lake_encrypt(data, field_type)
