import pytest


FUNCTION_NAME = \
    'cryptography_library.operations.criptography_client.check_permission'


def mock_access_denied(mocker):
    mocker.patch(
        FUNCTION_NAME,
        return_value=dict(
            has_access=False,
            user="vittor.pereira@br.experian.com"
        )
    )


def mock_access_permitted(mocker):
    mocker.patch(
        FUNCTION_NAME,
        return_value=dict(
            has_access=True,
            user="vittor.pereira@br.experian.com"
        )
    )
