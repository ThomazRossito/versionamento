import pytest
from py4j.protocol import Py4JJavaError
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from cryptography_library.operations import SparkCryptography

data = [["teste@serasa1.com.br", "123456789"],
        ["teste@serasa2.com.br", "987654321"]]

schema = (
    StructType()
    .add('userEmail', StringType(), False)
    .add('userDocument', StringType(), False)
)

spark = (
    SparkSession
    .builder
    .appName('criptography_lib_test')
    .getOrCreate()
)


@pytest.fixture
def spark_df():
    try:
        return spark.createDataFrame(data, schema)
    except Py4JJavaError:
        pytest.skip("Rodar fora da VPN com o databricks-connect")


@pytest.fixture
def crypto_client():
    return SparkCryptography()


def test_encrypt_email_happy_path(spark_df, crypto_client):
    pytest.skip("Implementação parcial")
    encryptEmail = crypto_client.get_encryption_function("email")
    print(spark_df.show())
    processed_df = (
        spark_df
        .withColumn("ds_email", encryptEmail("userEmail"))
    )

    result = processed_df.collect()
    expected = spark_df.collect()


def test_decrypt_email_happy_path(spark_df, crypto_client):
    pytest.skip("Implementação parcial")
    encryptEmail = crypto_client.get_encryption_function("email")
    decryptEmail = crypto_client.get_decryption_function("email")

    print(spark_df.show())

    processed_df = (
        spark_df
        .withColumn("ds_email", decryptEmail("userEmail"))
    )

    result = processed_df.collect()
    expected = spark_df.collect()


def test_encrypt_document_happy_path(spark_df, crypto_client):
    pytest.skip("Implementação parcial")
    encryptCpf = crypto_client.get_encryption_function("cpf")

    print(spark_df.show())

    processed_df = (
        spark_df
        .withColumn("ds_document", encryptCpf("userDocument"))
    )

    result = processed_df.collect()
    expected = spark_df.collect()


def test_decrypt_document_happy_path(spark_df, crypto_client):
    pytest.skip("Implementação parcial")
    decryptCpf = crypto_client.get_decryption_function("cpf")

    print(spark_df.show())

    processed_df = (
        spark_df
        .withColumn("ds_document", decryptCpf("userDocument"))
    )

    result = processed_df.collect()
    expected = spark_df.collect()
