import pytest
from .mocks import *
from cryptography_library.operations import CriptographyClient

'''
Cenarios de teste
  - Teste de caminho feliz encrypt lake
  - Teste de caminho feliz decrypt lake

  - Teste de caminho feliz encrypt document
  - Teste de caminho feliz decrypt document

  - field_type inexistente
  - decrypt: field_type não é o mesmo usado para fechar o dado.
'''

DOCUMENT_DATA = {
    "01888410005": "iT7zvBo4aD0HTjcYmf8SSw==$dicZnq2h3OJsRs4=",
    "01381203923": "z6YnmAoqG+Be8S6Djd1Crw==$dicSnqSn3eFlRMg="
}

EMAIL_DATA = {
    "vittor.pereira@br.experian.com":
    "A/GAtNbeaPu7ff7CzsM9zES5n7ms2JGx4fGbrMRBaSLetMQSKsXxKRTBGXOZDA==",
    "teste@br.experian.com":
    "Af2HtNzsJPnwauPb2dAUz1i5ma6x6eoPDm6Ek2qJ3tpPuiQgPw=="
}


@pytest.fixture
def client(mocker):
    mock_access_permitted(mocker)

    spark = None
    return CriptographyClient(spark)


def test_happy_path_data_lake_encryption(client):
    pytest.skip("Implementação pendente")
    # TODO: Mock the function "_get_data_key" in order to properly test
    # boto3 needs AWS autentication
    emails = list(EMAIL_DATA.keys())
    expected = list(EMAIL_DATA.values())

    response = client.encrypt(emails, "email")

    assert type(response) == list
    assert len(response) == 2
    for doc, cypher in zip(response, expected):
        assert doc == cypher


def test_happy_path_data_lake_decryption(client):
    pytest.skip("boto3 needs AWS autentication")
    # TODO: Mock the function "_get_data_key" in order to properly test
    # boto3 needs AWS autentication
    emails = list(EMAIL_DATA.keys())
    expected = list(EMAIL_DATA.values())

    response = client.decrypt(emails, "email")

    assert type(response) == list
    assert len(response) == 2
    for doc, cypher in zip(response, expected):
        assert doc == cypher


def test_happy_path_document_encryption(client):

    documents = list(DOCUMENT_DATA.keys())
    cypher = list(DOCUMENT_DATA.values())

    response = client.encrypt(documents, "cpf")

    assert type(response) == list
    assert len(response) == 2
    for given, expected in zip(response, cypher):
        assert given == expected


def test_happy_path_document_decryption(client):

    documents = list(DOCUMENT_DATA.keys())
    cypher = list(DOCUMENT_DATA.values())

    response = client.decrypt(cypher, "cpf")

    assert type(response) == list
    assert len(response) == 2
    for given, expected in zip(response, documents):
        assert given == expected


def test_invalid_type_encryption(client):

    documents = list(DOCUMENT_DATA.keys())

    with pytest.raises(ValueError) as exception:
        response = client.encrypt(documents, "tipo_que_nao_existe")

    error_message = str(exception.value)
    assert "Key not found" in error_message


def test_invalid_type_decryption(client):

    cypher = list(DOCUMENT_DATA.values())

    with pytest.raises(ValueError) as exception:
        response = client.decrypt(cypher, "tipo_que_nao_existe")

    error_message = str(exception.value)
    assert "Key not found" in error_message


def test_wrong_key_decryption(client):
    pytest.skip("boto3 needs AWS autentication")
    cypher = list(DOCUMENT_DATA.values())

    with pytest.raises(ValueError) as exception:
        response = client.decrypt(cypher, "email")

    error_message = str(exception.value)
    assert "Was not possible to decrypt data" in error_message


def test_null_values_encryption(client):
    pytest.skip("boto3 needs AWS autentication")
    source = [None] * 10

    response = client.encrypt(source, "email")

    for r in response:
        assert r is None


def test_permission_denied(mocker):
    mock_access_denied(mocker)

    spark = None

    with pytest.raises(AssertionError):
        CriptographyClient(spark)
