import re
import pytest
import pandas as pd
from cryptography_library.operations.commons \
    import PlatformCryptographyClient


data_true = [
    ["af", "FG+gV0SyMMjYCjyLeLzGYw==$Hvg=", "GO"],
    ["lno", "9YJO5SLoHPc=", "20324084"],
    ["lno", "8YdL4SHtFPV2prg=", "65667506300"]
]

data_false = [
    ["af", "FG+gV0SyMsjYCjyLeLzGYw==$Hvg=", "GO"],
    ["lno", "9Y78O5SghgrHPc=", "20324084"],
    ["lno", "8YdL4SHtsaV2prg=", "65667506300"]
]


def check_splcharacter(test):
    string_check = re.compile('[@_!#$%^&*()<>?/\\|}{~:]�')
    return string_check.search(test) is not None or ('\ufffdf' in test)


@pytest.fixture
def client():
    return PlatformCryptographyClient()


@pytest.mark.parametrize("product,cypher,source", data_true)
def test_happy_path_platform_decryption(client, product, cypher, source):
    response = client.decrypt([cypher], product)

    assert type(response) == list
    assert len(response) == 1
    assert source == response[0]


@pytest.mark.parametrize("product,cypher,source", data_false)
def test_wrong_cypher_platform_decryption(client, product, cypher, source):
    response = client.decrypt([cypher], product)

    assert type(response) == list
    assert len(response) == 1
    assert check_splcharacter(response[0]) or len(response[0]) == 0
